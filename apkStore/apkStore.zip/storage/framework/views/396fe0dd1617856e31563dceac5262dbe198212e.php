<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>">
    <!-- Page Title  -->
    <title> <?php echo $__env->yieldContent('title'); ?></title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashlite.css?ver=3.1.1')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/css/theme.css?ver=3.1.1')); ?>">

</head>

<body class="nk-body bg-white npc-default has-aside ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <div class="nk-header nk-header-fixed is-light">
                    <div class="container-lg wide-xl">
                        <div class="nk-header-wrap">
                            <div class="nk-header-brand">
                                <a href="html/index.html" class="logo-link">
                                    <img class="logo-light logo-img" src="<?php echo e(asset('images/logo.png')); ?>"
                                        srcset="./images/logo2x.png 2x" alt="logo">
                                    <img class="logo-dark logo-img" src="<?php echo e(asset('images/logo-dark.png')); ?>"
                                        srcset="./images/logo-dark2x.png 2x" alt="logo-dark">
                                </a>
                            </div><!-- .nk-header-brand -->
                            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div><!-- .nk-header-wrap -->
                    </div><!-- .container-fliud -->
                </div>
                <!-- main header @e -->
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="container wide-xl">
                        <div class="nk-content-inner">
                            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="nk-content-body">
                                <?php echo $__env->yieldContent('content'); ?>
                                <!-- footer @s -->
                                <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </div>
                        </div>
                    </div>
                    <!-- content @e -->
                </div>
                <!-- wrap @e -->
            </div>
            <!-- main @e -->
        </div>
        <!-- app-root @e -->
        <!-- JavaScript -->
        <script src="<?php echo e(asset('assets/js/bundle.js?ver=3.1.1')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/scripts.js?ver=3.1.1')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/libs/datatable-btns.js?ver=3.1.1')); ?>"></script>
</body>

</html>
<?php /**PATH F:\laragon\www\apkStore\resources\views\layouts\master.blade.php ENDPATH**/ ?>