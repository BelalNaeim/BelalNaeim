

<?php $__env->startSection('title'); ?>
    Dashboard | APK Store Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-content-wrap">
        <div class="components-preview wide-md mx-auto">
            <div class="row">
                <div class="col-md-4">
                    <div class="card card-bordered product-card">
                        <div class="product-thumb">
                            <a href="html/addNewServer.html">
                                <img class="card-img-top" src="<?php echo e(asset('images/addserver.png')); ?>" alt="">
                            </a>
                            <ul class="product-badges">
                                <li><span class="badge bg-danger">Important</span></li>
                            </ul>
                        </div>
                        <div class="card-inner text-center">
                            <h5 class="product-title"><a href="<?php echo e(url('dashboard/servers/create')); ?>">Add
                                    Server</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-bordered product-card">
                        <div class="product-thumb">
                            <a href="html/addNewApp.html">
                                <img class="card-img-top" src="<?php echo e(asset('images/addapp.png')); ?>" alt="">
                            </a>
                            <ul class="product-badges">
                                <li><span class="badge bg-danger">Important</span></li>
                            </ul>
                        </div>
                        <div class="card-inner text-center">
                            <h5 class="product-title"><a href="<?php echo e(url('dashboard/applications/create')); ?>">Add
                                    App</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-bordered product-card">
                        <div class="product-thumb">
                            <a href="html/manageNotifications.html">
                                <img class="card-img-top" src="<?php echo e(asset('images/sendnoti.png')); ?>" alt="">
                            </a>
                            <ul class="product-badges">
                                <li><span class="badge bg-success">Good</span></li>
                            </ul>
                        </div>
                        <div class="card-inner text-center">
                            <h5 class="product-title"><a href="#">Send
                                    Notification</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .components-preview -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\apkStore\resources\views\dashboard\index.blade.php ENDPATH**/ ?>