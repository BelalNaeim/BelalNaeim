-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2023 at 03:22 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apkstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `apps`
--

CREATE TABLE `apps` (
  `id` bigint UNSIGNED NOT NULL,
  `app_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_id` int NOT NULL,
  `app_version` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apk_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screenshots` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `app_info` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `apps`
--

INSERT INTO `apps` (`id`, `app_name`, `server_id`, `app_version`, `logo`, `apk_file`, `app_link`, `screenshots`, `app_info`, `created_at`, `updated_at`, `uuid`) VALUES
(4, 'Graiden Singleton', 6, 'Quia minus cupiditat', 'apps/logos/1685196490.jpg', NULL, 'https://www.lyjodimi.ca', 'apps/logos/1685196490BingImageOfTheDay_20211031.jpg|apps/logos/1685196490BingImageOfTheDay_20211124.jpg|apps/logos/1685196490BingImageOfTheDay-DESKTOP-EGLHOPV.jpg', 'Quaerat consequatur', '2023-05-27 11:08:10', '2023-05-27 11:08:10', NULL),
(5, 'Merrill Arnold', 6, 'Ea aspernatur offici', 'apps/logos/1685197397.png', 'apps/apks/1685197397.apk', NULL, 'apps/logos/16851973974k-ramadan-hd-wallpapers-98461-792434-8263204.png|apps/logos/16851973974k-ramadan-hd-wallpapers-98461-792507-5990332.png|apps/logos/1685197397peakpx (1).jpg', 'Quos aliquam magni a Quos aliquam magni a Quos aliquam magni a Quos aliquam magni a Quos aliquam magni a', '2023-05-27 11:23:17', '2023-05-27 11:23:17', '06473d90-fc9a-11ed-baaa-3b5d31d794a9');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_05_19_122358_create_servers_table', 1),
(6, '2023_05_19_161100_create_apps_table', 1),
(7, '2023_05_19_214724_create_settings_table', 1),
(8, '2023_05_27_141734_add_uuid_to_apps_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(8, 'App\\Models\\User', 2, 'apiToken', '0474a42ee8c2e1d251eca149f0d77643cc220221aae148d115ae21cdb73decd5', '[\"*\"]', NULL, NULL, '2023-05-20 21:00:14', '2023-05-20 21:00:14'),
(9, 'App\\Models\\User', 3, 'MyApp', '63ba35cb902d94fd16a1a9646d9bc931f812fce674681d0a6fe3dda6be6ab841', '[\"*\"]', NULL, NULL, '2023-05-20 21:07:34', '2023-05-20 21:07:34'),
(14, 'App\\Models\\User', 4, 'MyApp', '782772ac0291c624487043764aa47b497e16f29208d542ab1c6d8e130a55bd37', '[\"*\"]', NULL, NULL, '2023-05-22 11:25:54', '2023-05-22 11:25:54'),
(16, 'App\\Models\\User', 1, 'MyApp', 'c23c6498f5990a9771fb6ab41ee025d0ec03efa618b2e4868367271645e7e143', '[\"*\"]', '2023-05-22 11:30:17', NULL, '2023-05-22 11:28:28', '2023-05-22 11:30:17'),
(17, 'App\\Models\\User', 1, 'MyApp', '704bac599c632b176a96b12918c0e9b9caf88aa7e7935f858112a2a1a8fccc7f', '[\"*\"]', '2023-05-22 11:34:51', NULL, '2023-05-22 11:30:48', '2023-05-22 11:34:51'),
(18, 'App\\Models\\User', 1, 'MyApp', 'bacdf6a23ae8a703fca8fce68b955e97c39ea98123273c10791fe53482dc29df', '[\"*\"]', '2023-05-22 11:39:59', NULL, '2023-05-22 11:35:25', '2023-05-22 11:39:59'),
(19, 'App\\Models\\User', 1, 'MyApp', '702f1eacd7c3c163d500ca45803179a6e32732fa3feeda39993c2ab4b91cc0b7', '[\"*\"]', '2023-05-23 09:28:21', NULL, '2023-05-22 11:40:08', '2023-05-23 09:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `id` bigint UNSIGNED NOT NULL,
  `name` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `name`, `logo`, `server_data`, `created_at`, `updated_at`) VALUES
(6, 'Cameron Reyes', 'server/logos/1685196273.jpg', 'Libero accusamus dui Libero accusamus dui Libero accusamus dui Libero accusamus dui Libero accusamus dui Libero accusamus dui Libero accusamus dui', '2023-05-27 11:04:33', '2023-05-27 11:04:33');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint UNSIGNED NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-05-20 23:14:31', '2023-05-22 11:21:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Belal', 'belal.naeem@yahoo.com', NULL, '$2y$10$d1WPQoxwZ2mD4Op304k5wOCuqYFtdCiiXzT8IX7fE7vAP8yyR6Ehi', NULL, '2023-05-20 20:31:32', '2023-05-20 20:31:32'),
(2, 'mohamed', 'mohamedrizk15@gmail.com', NULL, '$2y$10$ORel4oJ..rinla8nIpmn9eRk0XQq1LbR/iHWXzqsV.CPwbXUJNcXS', NULL, '2023-05-20 21:00:14', '2023-05-20 21:00:14'),
(3, 'ahmed', 'ahmed@gmail.com', NULL, '$2y$10$k2vXt/KNbViehsFX6uuRN.v4iRcxqOkihQCdU8q8DMqQEC.sWUo1u', NULL, '2023-05-20 21:07:34', '2023-05-20 21:07:34'),
(4, 'hamed', 'hamed@gmail.com', NULL, '$2y$10$f/P1uNeMvPZrRxSsH4T81OswvbriD/iY9U14HHJXvoiTU1n5BK7Be', NULL, '2023-05-22 11:25:54', '2023-05-22 11:25:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apps`
--
ALTER TABLE `apps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apps`
--
ALTER TABLE `apps`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
