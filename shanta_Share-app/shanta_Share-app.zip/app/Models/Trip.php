<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Trip extends Model {
    use HasFactory;
    protected $table = 'trips';
    protected $fillable = [
        'user_id',
        'avwe',
        'fromcount',
        'fromcity',
        'tdt',
        'tocount',
        'tocity',
        'adt',
        'notes',
    ];

    public function user() {
        return $this->belongsTo( User::class );
    }
    protected $casts = [
        'tdt'=>'datetime',
        'adt'=>'datetime'
    ];

}
