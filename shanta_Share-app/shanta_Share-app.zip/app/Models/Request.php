<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Request extends Model {
    use HasFactory;
    protected $table = 'requests';
    protected $fillable = [
        'user_id',
        'adda',
        'fromcount',
        'tocount',
        'tocity',
        'shwe',
        'ndbfda',
        'prlink',
        'prname',
        'prtype',
        'prprice',
        'prquan',
        'primage',
        'prdet',
        'atdo',
    ];

    public function user() {
        return $this->belongsTo( User::class );
    }

    protected $casts = [
        'adda'=>'datetime',
        'ndbfda'=>'datetime'
    ];
}
