-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 19, 2023 at 12:08 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shantashare`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint UNSIGNED NOT NULL,
  `fromusername` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tousername` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mdt` datetime NOT NULL,
  `mcontent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `fromusername`, `tousername`, `mdt`, `mcontent`, `created_at`, `updated_at`) VALUES
(1, 'BelalNaeim', 'Jennifer Duran', '1988-04-23 12:11:00', 'Minus in ex sint si', '2023-06-18 20:38:43', '2023-06-18 20:38:43'),
(2, 'BelalNaeim', 'Jennifer Duran', '1988-04-23 12:11:00', 'test message test message test message test message test message test message', '2023-06-18 20:49:07', '2023-06-18 20:49:07'),
(3, 'BelalNaeim', 'Jennifer Duran', '1988-04-23 12:11:00', 'test message test message test message test message test message test message', '2023-06-18 21:07:20', '2023-06-18 21:07:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_06_17_114742_create_trips_table', 1),
(6, '2023_06_17_115511_create_shipments_table', 1),
(7, '2023_06_17_120039_create_requests_table', 1),
(8, '2023_06_17_120441_create_messages_table', 1),
(9, '2023_06_17_120702_create_settings_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'MyApp', '41f0ccd4f0322d7248639c3ba62b7ea3695f4225bbe3b9de771bd7962e987e0a', '[\"*\"]', '2023-06-18 20:04:59', NULL, '2023-06-18 18:54:34', '2023-06-18 20:04:59'),
(2, 'App\\Models\\User', 1, 'MyApp', '5449430dd6eb9c87578e0eb3c20cdc69ff4da00724e0e746b48d95b2397613be', '[\"*\"]', '2023-06-18 20:02:23', NULL, '2023-06-18 20:01:44', '2023-06-18 20:02:23'),
(3, 'App\\Models\\User', 1, 'MyApp', 'b42643482444cfe162ff58323a01d3d6fae0f9e76675e297198d224989f9d3f7', '[\"*\"]', '2023-06-18 20:50:50', NULL, '2023-06-18 20:04:22', '2023-06-18 20:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `adda` datetime NOT NULL,
  `fromcount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shwe` double(8,2) NOT NULL,
  `ndbfda` datetime NOT NULL,
  `prlink` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prtype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prprice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prquan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prdet` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `atdo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint UNSIGNED NOT NULL,
  `applogo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appfeesss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supportlink` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cslink` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `applogo`, `appfeesss`, `supportlink`, `cslink`, `created_at`, `updated_at`) VALUES
(1, 'logos/logo-dark2x.png', '20', 'http://shantashare.coders-island.com/', 'http://shantashare.coders-island.com/', '2023-06-18 21:01:32', '2023-06-18 21:01:32');

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `adda` datetime NOT NULL,
  `fromcount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromcity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shwe` double(8,2) NOT NULL,
  `ndbfda` datetime NOT NULL,
  `prlink` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prtype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prprice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prquan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prdet` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dshto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `atds` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`id`, `user_id`, `adda`, `fromcount`, `fromcity`, `tocount`, `tocity`, `shwe`, `ndbfda`, `prlink`, `prname`, `prtype`, `prprice`, `prquan`, `primage`, `prdet`, `dshto`, `atds`, `created_at`, `updated_at`) VALUES
(2, 1, '1979-10-26 20:04:00', 'Libya', 'Misrata', 'Algeria', 'Algeria', 68.00, '1979-10-26 20:04:00', 'test product', 'test product', 'test product', 'test product', 'test product', 'products/648f8ddaef8d6.jpg', 'test product', 'Specific Address', 'Ut voluptatem modi o', '2023-06-18 20:06:03', '2023-06-18 20:06:03');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `avwe` double(8,2) NOT NULL,
  `fromcount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromcity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tdt` datetime NOT NULL,
  `tocount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adt` datetime NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `user_id`, `avwe`, `fromcount`, `fromcity`, `tdt`, `tocount`, `tocity`, `adt`, `notes`, `created_at`, `updated_at`) VALUES
(2, 1, 66.00, 'Egypt', 'Mansoura', '1976-06-07 15:10:00', 'SaudiArbia', 'Riyadh', '1976-06-07 15:10:00', 'test test test test test test test test test', '2023-06-18 19:27:51', '2023-06-18 19:27:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `email_verified_at`, `phone_number`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'BelalNaeim', 'admin@app.com', NULL, '01099812636', '$2y$10$qLd2bez.4CRl3uUxjljdXecAUr4tLpNN8b9TJnWRCfLGB/uJrQ5iC', NULL, '2023-06-18 18:53:27', '2023-06-18 18:53:27'),
(2, 'Jennifer Duran', 'kakuc@mailinator.com', NULL, '01099712636', '$2y$10$ZH6/EnICLdUDdvTR3oIp2OK8LHKUH01wQ3v943s.UCHfUgLi8SffG', NULL, '2023-06-18 19:32:16', '2023-06-18 19:32:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requests_user_id_foreign` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shipments_user_id_foreign` (`user_id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trips_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `shipments`
--
ALTER TABLE `shipments`
  ADD CONSTRAINT `shipments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `trips`
--
ALTER TABLE `trips`
  ADD CONSTRAINT `trips_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
