<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;

class AdminUserSeeder extends Seeder {
    /**
    * Run the database seeds.
    *
    * @return void
    */

    public function run() {
        //
        User::create( [
            'full_name' => 'BelalNaeim',
            'email' => 'admin@app.com',
            'phone_number'=>'01099812636',
            'password' => bcrypt( '123456789' ),
        ] );
    }
}
