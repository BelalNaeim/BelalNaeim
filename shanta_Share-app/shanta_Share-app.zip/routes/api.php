<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ShipmentController as ApiShipmentController;
use App\Http\Controllers\Api\TripController as ApiTripController;
use App\Http\Controllers\Api\RequestController as ApiRequestController;
use App\Http\Controllers\Api\MessageController as ApiMessageController;
use App\Http\Controllers\Api\SettingController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the 'api' middleware group. Enjoy building your API!
|
*/
Route::post( '/v1/auth/register', [ AuthController::class, 'sign_up' ] );

Route::post( '/v1/auth/login', [ AuthController::class, 'login' ] );

Route::prefix('v1')->name('v1.')
->group(function () {

    Route::apiResource('users', UserController::class);
    Route::apiResource('trips', ApiTripController::class);
    Route::apiResource('shipments', ApiShipmentController::class);
    Route::apiResource('requests', ApiRequestController::class);
    Route::apiResource('messages', ApiMessageController::class);
    Route::get( '/settings', [ SettingController::class, 'Setting' ] );


   

});


