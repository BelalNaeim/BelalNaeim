@extends('layouts.master')

@section('title')
    Trips | ShantaShare App
@endsection

@section('content')
    <div class="nk-content-wrap">
        <div class="components-preview wide-md mx-auto">
            <div class="nk-block-head nk-block-head-lg wide-sm">
                <div class="nk-block-head-content">
                    <div class="nk-block-head-sub"><a class="back-to" href="html/trips.html"><em
                                class="icon ni ni-arrow-left"></em><span>Trips List</span></a></div>
                    <h2 class="nk-block-title fw-normal">Add New Trip</h2>
                </div>
            </div><!-- .nk-block-head -->
            <div class="nk-block nk-block-lg">
                <div class="card card-bordered card-preview">
                    <div class="card-inner">
                        <form method="POST" action="{{ route('trips.store') }}">
                            @csrf
                            <div class="preview-block">
                                <hr>
                                @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                        @foreach ($errors->all() as $err)
                                            <li>{{ $err }}</li>
                                        @endforeach
                                    </div>
                                @endif
                                <div class="preview-block">
                                    <span class="preview-title-lg overline-title">Fill Required Data</span>
                                    <div class="row gy-4">


                                        <div class="col-lg-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="user_id">User</label>
                                                    <select class="form-select form-control-xl" id="user_id"
                                                        name="user_id">
                                                        <option disabled="" selected="">--Select User--</option>
                                                        @foreach ($users as $user)
                                                            <option value="{{ $user->id }}">{{ $user->full_name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="avwe">Available Weight</label>
                                                    <input type="number" class="form-control form-control-xl"
                                                        id="avwe" name="avwe">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="fromcount">From Country</label>
                                                    <input type="text" class="form-control form-control-xl"
                                                        id="fromcount" name="fromcount">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="fromcity">From City</label>
                                                    <input type="text" class="form-control form-control-xl"
                                                        id="fromcity" name="fromcity">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="tdt">Travel Date and Time</label>
                                                    <input type="datetime-local" class="form-control form-control-xl"
                                                        id="tdt" name="tdt">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="tocount">To Country</label>
                                                    <input type="text" class="form-control form-control-xl"
                                                        id="tocount" name="tocount">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="tocity">To City</label>
                                                    <input type="text" class="form-control form-control-xl"
                                                        id="tocity" name="tocity">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="adt">Arrive Date and Time</label>
                                                    <input type="datetime-local" class="form-control form-control-xl"
                                                        id="adt" name="adt">
                                                </div>
                                            </div>
                                        </div>


                                        <hr />
                                        <div class="col-lg-12 col-sm-12">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="notes">Notes</label>
                                                    <textarea class="form-control" id="notes" name="notes"></textarea>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <hr class="preview-hr">
                                    <div style="text-align:right;">
                                        <button class="btn btn-lg btn-success" type="submit">Save Data</button>
                                        <button class="btn btn-lg btn-danger" type="reset">Clear Data</button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div><!-- .card-preview -->
            </div><!-- .nk-block -->
        </div><!-- .components-preview -->
    </div>
</ @endsection
