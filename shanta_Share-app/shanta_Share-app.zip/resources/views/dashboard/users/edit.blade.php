@extends('layouts.master')

@section('title')
    Users | ShantaShare App
@endsection

@section('content')
    <div class="nk-content-wrap">
        <div class="components-preview wide-md mx-auto">
            <div class="nk-block-head nk-block-head-lg wide-sm">
                <div class="nk-block-head-content">
                    <div class="nk-block-head-sub"><a class="back-to" href="{{ route('users.create') }}"><em
                                class="icon ni ni-arrow-left"></em><span>Users List</span></a></div>
                    <h2 class="nk-block-title fw-normal">Add New User</h2>
                </div>
            </div><!-- .nk-block-head -->
            <div class="nk-block nk-block-lg">
                <div class="card card-bordered card-preview">
                    <div class="card-inner">
                        <form method="POST" action="{{ route('users.update', $user->id) }}">
                            @method('PUT')
                            @csrf
                            <div class="preview-block">
                                <hr>
                                @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                        @foreach ($errors->all() as $err)
                                            <li>{{ $err }}</li>
                                        @endforeach
                                    </div>
                                @endif
                                <div class="preview-block">
                                    <span class="preview-title-lg overline-title">Fill Required Data</span>
                                    <div class="row gy-4">
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="full-name">Full Name</label>
                                                    <input type="text" class="form-control form-control-xl"
                                                        id="full-name" Name="full_name" value="{{ $user->full_name }}">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="email">Email</label>
                                                    <input type="email" class="form-control form-control-xl"
                                                        id="email" Name="email" value="{{ $user->email }}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-sm-4">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="phone_number">Phone Number</label>
                                                    <input type="tel" class="form-control form-control-xl"
                                                        id="phone_number" Name="phone_number" value="{{ $user->phnumber }}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="password">Password</label>
                                                    <input type="password" class="form-control form-control-xl"
                                                        id="password" Name="password" value="{{ $user->password }}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-6">
                                            <div class="form-group">
                                                <div class="form-control-wrap">
                                                    <label for="cpassword">Confirm Password</label>
                                                    <input type="password" class="form-control form-control-xl"
                                                        id="cpassword" Name="password_confirmation"
                                                        value="{{ $user->password }}">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <hr class="preview-hr">
                                    <div style="text-align:right;">
                                        <button class="btn btn-lg btn-success" type="submit">Save Data</button>
                                        <button class="btn btn-lg btn-danger" type="reset">Clear Data</button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div><!-- .card-preview -->
            </div><!-- .nk-block -->
        </div><!-- .components-preview -->
    </div>
</ @endsection
